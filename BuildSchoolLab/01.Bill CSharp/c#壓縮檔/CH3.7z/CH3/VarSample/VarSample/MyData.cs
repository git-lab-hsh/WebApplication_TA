﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VarSample
{
    class MyData
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}
