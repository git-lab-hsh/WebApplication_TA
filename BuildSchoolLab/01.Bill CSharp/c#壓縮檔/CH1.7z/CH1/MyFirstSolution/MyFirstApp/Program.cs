﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstApp
{
    /// <summary>
    /// 
    /// </summary>
    class Program
    {
        /// <summary>
        /// BCCCCC
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
           Console.WriteLine("Hello C#");          
           Console.ReadLine();            
        }



        
    }
}
