﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstSample
{
    public class Class1
    {
        public const int MAX = 100;
        public const int MIN = 0;
        public const int COUNT_OF_BOOKS = 999;
    }
}
