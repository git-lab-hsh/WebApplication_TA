﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextFileSample003
{
    class Restaurant
    {
        public int Seq { get; set; }

        public string DishName { get; set; }

        public string Shop { get; set; }

        public string Address { get; set; }

        public string Tel { get; set; }
    }
}
