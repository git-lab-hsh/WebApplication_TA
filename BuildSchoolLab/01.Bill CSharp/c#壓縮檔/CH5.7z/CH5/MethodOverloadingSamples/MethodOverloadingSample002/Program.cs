﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloadingSample002
{
    class Program
    {
        static void Main(string[] args)
        {
        }

        // 以下是不合法的多載，因為只有回傳值不同 
        // 所以我整個都註解掉了，可以把所有註解取消，試試看 Visual Studio 會告訴你甚麼

        //static void Add()
        //{
        //}

        //static int Add()
        //{
        //}

        //static void Sub(int x)
        //{
        //}

        //static int Sub(int y)
        //{
        //}
    }
}
